#!bin/bash
mkdir /home/user/SkillFactory_HW
