#!bin/bash
date "+%d-%m-%Y %H-%M-%S"
